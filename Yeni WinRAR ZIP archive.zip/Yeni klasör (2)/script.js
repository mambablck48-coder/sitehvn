/* ============================================
   🌙 Gece Bahçesinde Açan Aşk — Script v3
   Ultra-realistic canvas peony — bulletproof
   ============================================ */

(function () {
    'use strict';

    /* ==================== STATE ==================== */
    var STATE = {
        phase: 'init',
        hasWatered: false,
        bloomProgress: 0,
        wiltProgress: 0,
        reviveProgress: 0,
        flowerCenterX: 0,
        flowerCenterY: 0
    };

    /* ==================== EASING ==================== */
    function easeInOutCubic(t) {
        return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
    }
    function easeOutQuad(t) {
        return 1 - (1 - t) * (1 - t);
    }

    /* ==================== STARS ==================== */
    function initStars() {
        var canvas = document.getElementById('starsCanvas');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');
        var stars = [];
        var count = window.innerWidth < 480 ? 90 : 180;

        function resize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }

        function create() {
            stars = [];
            for (var i = 0; i < count; i++) {
                stars.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    r: Math.random() * 1.8 + 0.3,
                    alpha: Math.random() * 0.8 + 0.2,
                    speed: Math.random() * 0.005 + 0.002,
                    phase: Math.random() * Math.PI * 2,
                    hue: Math.random() > 0.6 ? (Math.random() * 50 + 230) : 0
                });
            }
        }

        function draw(time) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            for (var i = 0; i < stars.length; i++) {
                var s = stars[i];
                var twinkle = Math.sin(time * s.speed + s.phase) * 0.4 + 0.6;
                var a = s.alpha * twinkle;
                ctx.fillStyle = s.hue
                    ? 'hsla(' + s.hue + ', 60%, 82%, ' + a + ')'
                    : 'rgba(255, 255, 255, ' + a + ')';
                ctx.beginPath();
                ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
                ctx.fill();
                if (s.r > 1.2) {
                    ctx.fillStyle = 'rgba(220, 200, 255, ' + (a * 0.12) + ')';
                    ctx.beginPath();
                    ctx.arc(s.x, s.y, s.r * 3.5, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
            requestAnimationFrame(draw);
        }

        resize();
        create();
        requestAnimationFrame(draw);
        window.addEventListener('resize', function () { resize(); create(); });
    }

    /* ==================== PETAL DATA ==================== */
    function createPetals() {
        var petals = [];

        function addPetal(layer, angle, radius, w, h, hue, sat, light, alpha) {
            petals.push({
                layer: layer,
                angle: angle + (Math.random() - 0.5) * 14,
                radius: radius + (Math.random() - 0.5) * 8,
                w: w + (Math.random() - 0.5) * 6,
                h: h + (Math.random() - 0.5) * 5,
                hue: hue + (Math.random() - 0.5) * 8,
                sat: sat + (Math.random() - 0.5) * 5,
                light: light + (Math.random() - 0.5) * 4,
                alpha: alpha,
                windPhase: Math.random() * Math.PI * 2,
                windAmp: 0.5 + Math.random() * 1.0,
                bloomStart: layer * 0.12 + Math.random() * 0.08,
                bloomEnd: layer * 0.12 + 0.22 + Math.random() * 0.1,
                wiltDelay: Math.random() * 0.3,
                curve: (Math.random() - 0.5) * 12,
                tipShape: 0.35 + Math.random() * 0.3
            });
        }

        var i, a, n;

        // Layer 0 — innermost, small, lightest
        n = 8;
        for (i = 0; i < n; i++) { a = (360 / n) * i; addPetal(0, a, 12, 18, 24, 340, 50, 90, 1); }

        // Layer 1
        n = 10;
        for (i = 0; i < n; i++) { a = (360 / n) * i + 18; addPetal(1, a, 24, 24, 32, 338, 55, 86, 1); }

        // Layer 2
        n = 12;
        for (i = 0; i < n; i++) { a = (360 / n) * i + 8; addPetal(2, a, 38, 30, 42, 336, 58, 82, 1); }

        // Layer 3
        n = 14;
        for (i = 0; i < n; i++) { a = (360 / n) * i + 4; addPetal(3, a, 54, 36, 50, 334, 55, 78, 0.95); }

        // Layer 4
        n = 14;
        for (i = 0; i < n; i++) { a = (360 / n) * i + 14; addPetal(4, a, 70, 42, 58, 332, 50, 74, 0.9); }

        // Layer 5 — outermost guard petals
        n = 10;
        for (i = 0; i < n; i++) { a = (360 / n) * i + 20; addPetal(5, a, 84, 48, 62, 330, 44, 70, 0.85); }

        // Sort: outer layers drawn first (behind), inner layers on top
        petals.sort(function (a, b) { return b.layer - a.layer; });

        return petals;
    }

    /* ==================== FLOWER RENDERER ==================== */
    function initFlower() {
        var canvas = document.getElementById('flowerCanvas');
        if (!canvas) { console.error('flowerCanvas not found'); return; }
        var ctx = canvas.getContext('2d');
        var scene = document.getElementById('flowerScene');
        var petals = createPetals();

        function resize() {
            var rect = scene.getBoundingClientRect();
            var w = rect.width || 420;
            var h = rect.height || 520;
            canvas.width = w * 2;   // 2x for sharpness
            canvas.height = h * 2;
            canvas.style.width = w + 'px';
            canvas.style.height = h + 'px';
        }

        resize();
        window.addEventListener('resize', resize);

        function logicalW() { return canvas.width / 2; }
        function logicalH() { return canvas.height / 2; }
        function cx() { return logicalW() / 2; }
        function cy() { return logicalH() * 0.44; }

        /* --- Stem --- */
        function drawStem() {
            var x = cx(), y = cy(), by = logicalH() * 0.93;
            var wilt = STATE.wiltProgress;
            var rev = STATE.reviveProgress;
            var droop = wilt * (1 - rev);

            var cp1x = x + droop * 35;
            var cp1y = y + (by - y) * 0.35;
            var cp2x = x + droop * 20;
            var cp2y = y + (by - y) * 0.65;

            var greenL = 35 - droop * 8 + rev * 8;

            ctx.strokeStyle = 'hsl(120, 38%, ' + greenL + '%)';
            ctx.lineWidth = 5;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(x, y + 45);
            ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, x + droop * 10, by);
            ctx.stroke();

            // Leaves
            drawLeaf(x + droop * 12, y + (by - y) * 0.38, -35 + droop * 10, 34, 18, greenL);
            drawLeaf(x + droop * 18, y + (by - y) * 0.58, 30 + droop * 5, 30, 16, greenL - 2);
        }

        function drawLeaf(x, y, angleDeg, len, w, lightness) {
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(angleDeg * Math.PI / 180);
            ctx.fillStyle = 'hsla(125, 45%, ' + lightness + '%, 0.85)';
            ctx.beginPath();
            ctx.moveTo(0, 0);
            ctx.quadraticCurveTo(len * 0.5, -w, len, 0);
            ctx.quadraticCurveTo(len * 0.5, w, 0, 0);
            ctx.fill();

            // Vein
            ctx.strokeStyle = 'hsla(125, 30%, ' + (lightness - 8) + '%, 0.35)';
            ctx.lineWidth = 0.6;
            ctx.beginPath();
            ctx.moveTo(2, 0);
            ctx.lineTo(len - 3, 0);
            ctx.stroke();
            ctx.restore();
        }

        /* --- Bud --- */
        function drawBud() {
            var bloom = STATE.bloomProgress;
            var budAlpha = Math.max(0, 1 - bloom * 4);
            if (budAlpha <= 0) return;

            var x = cx(), y = cy();
            ctx.save();
            ctx.globalAlpha = budAlpha;

            // Green sepals
            ctx.fillStyle = '#3a8a2a';
            ctx.beginPath();
            ctx.moveTo(x, y - 28);
            ctx.quadraticCurveTo(x - 18, y, x, y + 28);
            ctx.quadraticCurveTo(x + 18, y, x, y - 28);
            ctx.fill();

            ctx.fillStyle = '#2d7a20';
            ctx.beginPath();
            ctx.moveTo(x - 3, y - 24);
            ctx.quadraticCurveTo(x - 20, y + 2, x - 3, y + 24);
            ctx.quadraticCurveTo(x + 4, y + 2, x - 3, y - 24);
            ctx.fill();

            ctx.fillStyle = '#2d7a20';
            ctx.beginPath();
            ctx.moveTo(x + 3, y - 24);
            ctx.quadraticCurveTo(x + 20, y + 2, x + 3, y + 24);
            ctx.quadraticCurveTo(x - 4, y + 2, x + 3, y - 24);
            ctx.fill();

            // Pink hint at top
            ctx.fillStyle = 'hsla(340, 55%, 80%, ' + (budAlpha * 0.6) + ')';
            ctx.beginPath();
            ctx.arc(x, y - 8, 10, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
        }

        /* --- Single Petal --- */
        function drawPetal(p, time) {
            var bloom = STATE.bloomProgress;
            var wilt = STATE.wiltProgress;
            var rev = STATE.reviveProgress;

            // How open is this petal?
            var open = 0;
            if (bloom >= p.bloomEnd) {
                open = 1;
            } else if (bloom > p.bloomStart) {
                open = easeOutQuad((bloom - p.bloomStart) / (p.bloomEnd - p.bloomStart));
            }
            if (open < 0.02) return;

            // Wilt
            var wiltAmt = Math.max(0, Math.min(1, (wilt - p.wiltDelay) / Math.max(0.01, 1 - p.wiltDelay)));
            var effWilt = wiltAmt * (1 - rev);

            // Wind sway
            var wind = Math.sin(time * 0.0008 + p.windPhase) * p.windAmp * open * (1 - effWilt * 0.5);

            // Position
            var angleDeg = p.angle + wind + p.curve * open;
            var closedR = 4;
            var finalR = closedR + (p.radius - closedR) * open;
            var droopY = effWilt * (p.layer * 5 + 6);

            var rad = angleDeg * Math.PI / 180;
            var px = cx() + Math.cos(rad) * finalR;
            var py = cy() + Math.sin(rad) * finalR * 0.55 + droopY;

            // Size
            var sw = p.w * open;
            var sh = p.h * open;
            var hw = sw / 2;
            var hh = sh / 2;

            if (hw < 0.5 || hh < 0.5) return;

            // Colors — wilt shifts hue to brown, desaturates
            var hue = p.hue + effWilt * 18;
            var sat = p.sat * (1 - effWilt * 0.6);
            var light = p.light - effWilt * 18;
            var alpha = p.alpha * (1 - effWilt * 0.25);

            ctx.save();
            ctx.translate(px, py);
            ctx.rotate(rad + effWilt * 0.25);

            // ===== PETAL SHAPE (bezier curves, no ellipse API) =====
            var baseColor = 'hsla(' + hue + ',' + (sat + 5) + '%,' + (light + 6) + '%,' + alpha + ')';
            var edgeColor = 'hsla(' + (hue - 3) + ',' + (sat + 2) + '%,' + (light - 3) + '%,' + (alpha * 0.85) + ')';

            // Radial gradient for the petal
            var maxR = Math.max(hw, hh);
            var grad = ctx.createRadialGradient(0, hh * 0.2, 0, 0, 0, maxR);
            grad.addColorStop(0, baseColor);
            grad.addColorStop(0.6, 'hsla(' + hue + ',' + sat + '%,' + light + '%,' + alpha + ')');
            grad.addColorStop(1, edgeColor);
            ctx.fillStyle = grad;

            ctx.beginPath();
            ctx.moveTo(0, hh); // base point (attached to center)

            // Right side curve
            ctx.bezierCurveTo(
                hw * 0.55, hh * 0.55,
                hw * 1.05, -hh * 0.15,
                hw * p.tipShape, -hh
            );

            // Tip curve (top)
            ctx.bezierCurveTo(
                hw * 0.08, -hh * 1.15,
                -hw * 0.08, -hh * 1.15,
                -hw * p.tipShape, -hh
            );

            // Left side curve
            ctx.bezierCurveTo(
                -hw * 1.05, -hh * 0.15,
                -hw * 0.55, hh * 0.55,
                0, hh
            );

            ctx.closePath();
            ctx.fill();

            // Vein lines
            ctx.strokeStyle = 'hsla(' + hue + ',' + (sat - 15) + '%,' + (light - 10) + '%,' + (alpha * 0.12) + ')';
            ctx.lineWidth = 0.35;
            for (var v = -2; v <= 2; v++) {
                var vx = v * hw * 0.22;
                ctx.beginPath();
                ctx.moveTo(0, hh * 0.4);
                ctx.quadraticCurveTo(vx * 0.7, 0, vx * 1.1, -hh * 0.65);
                ctx.stroke();
            }

            // Highlight / shine
            ctx.fillStyle = 'hsla(' + hue + ', 25%, 96%, ' + (alpha * 0.14 * open) + ')';
            ctx.beginPath();
            ctx.arc(hw * 0.12, -hh * 0.15, Math.min(hw * 0.4, hh * 0.35), 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
        }

        /* --- Flower Center --- */
        function drawCenter() {
            var bloom = STATE.bloomProgress;
            if (bloom < 0.2) return;
            var wilt = STATE.wiltProgress;
            var rev = STATE.reviveProgress;
            var effWilt = wilt * (1 - rev);
            var x = cx(), y = cy();
            var r = 12 + bloom * 5;
            var centerL = 85 - effWilt * 20;

            var grad = ctx.createRadialGradient(x, y, 0, x, y, r);
            grad.addColorStop(0, 'hsla(45, 70%, ' + centerL + '%, 0.9)');
            grad.addColorStop(0.5, 'hsla(40, 55%, ' + (centerL - 10) + '%, 0.8)');
            grad.addColorStop(1, 'hsla(340, 45%, ' + (centerL - 15) + '%, 0.5)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(x, y, r, 0, Math.PI * 2);
            ctx.fill();

            // Tiny stamens
            if (bloom > 0.5) {
                var sa = Math.min(1, (bloom - 0.5) * 2) * (1 - effWilt * 0.5);
                for (var i = 0; i < 14; i++) {
                    var ang = (Math.PI * 2 * i) / 14;
                    var sr = r * 0.55 + Math.sin(i * 3.7) * 2;
                    ctx.fillStyle = 'hsla(45, 80%, 72%, ' + (sa * 0.55) + ')';
                    ctx.beginPath();
                    ctx.arc(x + Math.cos(ang) * sr, y + Math.sin(ang) * sr * 0.7, 1.3, 0, Math.PI * 2);
                    ctx.fill();
                }
            }
        }

        /* --- Revival Glow --- */
        function drawRevivalGlow() {
            if (STATE.reviveProgress < 0.3) return;
            var x = cx(), y = cy();
            var a = (STATE.reviveProgress - 0.3) * 0.35;
            var grad = ctx.createRadialGradient(x, y, 8, x, y, 110);
            grad.addColorStop(0, 'hsla(340,60%,85%,' + a + ')');
            grad.addColorStop(1, 'hsla(340,60%,85%,0)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(x, y, 110, 0, Math.PI * 2);
            ctx.fill();
        }

        /* --- Main render loop --- */
        function render(time) {
            var w = logicalW(), h = logicalH();

            // Update screen-space flower center for water targeting
            var sceneRect = scene.getBoundingClientRect();
            STATE.flowerCenterX = sceneRect.left + sceneRect.width / 2;
            STATE.flowerCenterY = sceneRect.top + sceneRect.height * 0.44;

            ctx.save();
            ctx.scale(2, 2); // match the 2x canvas
            ctx.clearRect(0, 0, w, h);

            drawStem();
            drawBud();

            for (var i = 0; i < petals.length; i++) {
                drawPetal(petals[i], time);
            }

            drawCenter();
            drawRevivalGlow();

            ctx.restore();
            requestAnimationFrame(render);
        }

        requestAnimationFrame(render);
    }

    /* ==================== ANIMATION TIMELINE ==================== */
    function startTimeline() {
        // Phase 1: Bloom
        setTimeout(function () {
            STATE.phase = 'blooming';
            animateValue('bloomProgress', 0, 1, 3500, easeInOutCubic, function () {
                document.getElementById('flowerGlow').classList.add('active');
                // Phase 2: Wilt after 3s pause
                setTimeout(function () {
                    STATE.phase = 'wilting';
                    animateValue('wiltProgress', 0, 1, 3000, easeInOutCubic, function () {
                        STATE.phase = 'waiting';
                        createFallingPetals();
                        showWateringCan();
                    });
                }, 3000);
            });
        }, 1000);
    }

    function animateValue(prop, from, to, dur, ease, cb) {
        var start = performance.now();
        function step(now) {
            var t = Math.min((now - start) / dur, 1);
            STATE[prop] = from + (to - from) * ease(t);
            if (t < 1) {
                requestAnimationFrame(step);
            } else {
                if (cb) cb();
            }
        }
        requestAnimationFrame(step);
    }

    /* ==================== FALLING PETALS ==================== */
    function createFallingPetals() {
        // Add keyframes
        if (!document.getElementById('petalFallCSS')) {
            var style = document.createElement('style');
            style.id = 'petalFallCSS';
            style.textContent =
                '@keyframes petalFall{' +
                '0%{transform:translateY(0) rotate(0) scale(1);opacity:.7}' +
                '30%{transform:translateY(60px) rotate(120deg) translateX(25px) scale(.9);opacity:.6}' +
                '60%{transform:translateY(150px) rotate(240deg) translateX(-15px) scale(.6);opacity:.4}' +
                '100%{transform:translateY(300px) rotate(400deg) translateX(10px) scale(.2);opacity:0}}';
            document.head.appendChild(style);
        }

        var scene = document.getElementById('flowerScene');
        for (var i = 0; i < 8; i++) {
            (function (idx) {
                setTimeout(function () {
                    var p = document.createElement('div');
                    p.style.cssText =
                        'position:absolute;' +
                        'width:' + (12 + Math.random() * 8) + 'px;' +
                        'height:' + (8 + Math.random() * 6) + 'px;' +
                        'background:hsl(' + (335 + Math.random() * 15) + ',' + (35 + Math.random() * 20) + '%,' + (65 + Math.random() * 15) + '%);' +
                        'border-radius:50% 50% 50% 0;' +
                        'opacity:.7;' +
                        'left:' + (35 + Math.random() * 30) + '%;' +
                        'top:' + (28 + Math.random() * 15) + '%;' +
                        'pointer-events:none;z-index:6;' +
                        'animation:petalFall ' + (2.5 + Math.random() * 2) + 's linear forwards;';
                    scene.appendChild(p);
                    setTimeout(function () { p.remove(); }, 4500);
                }, idx * 350);
            })(i);
        }
    }

    /* ==================== WATERING CAN ==================== */
    function showWateringCan() {
        var container = document.getElementById('wateringCanContainer');
        container.classList.add('visible');
        initWatering();
    }

    function initWatering() {
        var can = document.getElementById('wateringCan');
        var isDragging = false;
        var dragClone = null;
        var offX = 0, offY = 0;

        can.addEventListener('click', function (e) {
            if (isDragging || STATE.hasWatered) return;
            e.preventDefault();
            doWater();
        });

        function startDrag(e) {
            if (STATE.hasWatered) return;
            isDragging = true;
            var rect = can.getBoundingClientRect();
            var cX = e.touches ? e.touches[0].clientX : e.clientX;
            var cY = e.touches ? e.touches[0].clientY : e.clientY;
            offX = cX - rect.left;
            offY = cY - rect.top;
            dragClone = can.cloneNode(true);
            dragClone.classList.add('dragging');
            dragClone.style.width = rect.width + 'px';
            document.body.appendChild(dragClone);
            moveDrag(cX, cY);
            can.style.opacity = '0.3';
        }

        function moveDrag(cX, cY) {
            if (!dragClone) return;
            dragClone.style.left = (cX - offX) + 'px';
            dragClone.style.top = (cY - offY) + 'px';
        }

        function endDrag(e) {
            if (!isDragging) return;
            isDragging = false;
            var cX = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
            var cY = e.changedTouches ? e.changedTouches[0].clientY : e.clientY;
            var fr = document.getElementById('flowerScene').getBoundingClientRect();
            var onFlower = cX >= fr.left - 50 && cX <= fr.right + 50 && cY >= fr.top - 50 && cY <= fr.bottom + 50;
            if (dragClone) { dragClone.remove(); dragClone = null; }
            can.style.opacity = '1';
            if (onFlower && !STATE.hasWatered) doWater();
        }

        can.addEventListener('mousedown', startDrag);
        document.addEventListener('mousemove', function (e) { if (isDragging) { e.preventDefault(); moveDrag(e.clientX, e.clientY); } });
        document.addEventListener('mouseup', endDrag);
        can.addEventListener('touchstart', function (e) { e.preventDefault(); startDrag(e); }, { passive: false });
        document.addEventListener('touchmove', function (e) { if (isDragging) moveDrag(e.touches[0].clientX, e.touches[0].clientY); }, { passive: true });
        document.addEventListener('touchend', endDrag);
    }

    function doWater() {
        if (STATE.hasWatered) return;
        STATE.hasWatered = true;
        STATE.phase = 'watering';
        var can = document.getElementById('wateringCan');
        can.classList.add('pouring');
        startWaterDrops();
        setTimeout(function () {
            document.getElementById('wateringCanContainer').classList.add('hidden');
        }, 2000);
        setTimeout(function () {
            STATE.phase = 'reviving';
            reviveFlower();
        }, 2800);
    }

    /* ==================== WATER DROPS ==================== */
    function startWaterDrops() {
        var canvas = document.getElementById('waterCanvas');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        // Target: flower center — FROM STATE (screen coords)
        var tX = STATE.flowerCenterX;
        var tY = STATE.flowerCenterY;

        var drops = [];
        var t0 = performance.now();
        var duration = 2500;

        var spawner = setInterval(function () {
            for (var i = 0; i < 4; i++) {
                drops.push({
                    x: tX + (Math.random() - 0.5) * 50,
                    y: tY - 45 - Math.random() * 25,
                    vx: (Math.random() - 0.5) * 0.5,
                    vy: 1.5 + Math.random() * 2.5,
                    r: 2.5 + Math.random() * 3,
                    landed: false,
                    targetY: tY + (Math.random() - 0.5) * 20,
                    splashTime: 0
                });
            }
        }, 70);

        function animate(now) {
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            for (var i = 0; i < drops.length; i++) {
                var d = drops[i];
                if (!d.landed) {
                    d.vy += 0.12;
                    d.x += d.vx;
                    d.y += d.vy;
                    if (d.y >= d.targetY) {
                        d.landed = true;
                        d.splashTime = now;
                        document.getElementById('flowerGlow').classList.add('active', 'watered');
                    }
                }

                if (!d.landed) {
                    ctx.save();
                    ctx.globalAlpha = 0.85;
                    var g = ctx.createRadialGradient(d.x, d.y, 0, d.x, d.y, d.r);
                    g.addColorStop(0, 'rgba(160,215,255,0.95)');
                    g.addColorStop(0.5, 'rgba(110,185,245,0.7)');
                    g.addColorStop(1, 'rgba(80,160,230,0)');
                    ctx.fillStyle = g;
                    ctx.beginPath();
                    // Teardrop shape
                    ctx.moveTo(d.x, d.y - d.r * 1.5);
                    ctx.quadraticCurveTo(d.x + d.r, d.y, d.x, d.y + d.r);
                    ctx.quadraticCurveTo(d.x - d.r, d.y, d.x, d.y - d.r * 1.5);
                    ctx.fill();
                    ctx.restore();
                } else {
                    var elapsed = now - d.splashTime;
                    if (elapsed < 700) {
                        var prog = elapsed / 700;
                        var rr = d.r * (1 + prog * 8);
                        ctx.save();
                        ctx.globalAlpha = (1 - prog) * 0.45;
                        ctx.strokeStyle = 'rgba(180,220,255,0.6)';
                        ctx.lineWidth = 1.2;
                        ctx.beginPath();
                        ctx.arc(d.x, d.y, rr, 0, Math.PI * 2);
                        ctx.stroke();
                        // Sparkle
                        if (prog < 0.35) {
                            ctx.fillStyle = 'rgba(255,255,255,' + ((0.35 - prog) * 2) + ')';
                            ctx.beginPath();
                            ctx.arc(d.x + rr * 0.4, d.y - rr * 0.3, 1.5 + prog * 3, 0, Math.PI * 2);
                            ctx.fill();
                        }
                        ctx.restore();
                    }
                }
            }

            // Clean old
            for (var j = drops.length - 1; j >= 0; j--) {
                if (drops[j].landed && now - drops[j].splashTime > 900) drops.splice(j, 1);
            }

            if (now - t0 < duration + 1200) {
                requestAnimationFrame(animate);
            } else {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            }
        }

        requestAnimationFrame(animate);
        setTimeout(function () { clearInterval(spawner); }, duration);
    }

    /* ==================== REVIVE ==================== */
    function reviveFlower() {
        document.getElementById('flowerGlow').classList.add('active', 'watered');
        animateValue('reviveProgress', 0, 1, 2500, easeInOutCubic, function () {
            setTimeout(startFireworks, 300);
            setTimeout(function () {
                STATE.phase = 'message';
                showMessage();
            }, 2000);
        });
    }

    /* ==================== FIREWORKS ==================== */
    function startFireworks() {
        var canvas = document.getElementById('fireworksCanvas');
        if (!canvas) return;
        var ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        canvas.classList.add('active');

        var particles = [];
        var rockets = [];
        var colors = [
            '#f8c8dc', '#e8a0c8', '#d090b8',
            '#ffd700', '#ffb347', '#f5c542',
            '#c8a0e8', '#a080d0', '#b090e0',
            '#ffffff', '#ffe0f0'
        ];
        var fwCount = 0;
        var maxFw = 9;
        var lastT = performance.now();

        function launch() {
            if (fwCount >= maxFw) return;
            fwCount++;
            rockets.push({
                x: canvas.width * (0.15 + Math.random() * 0.7),
                y: canvas.height,
                ty: canvas.height * (0.1 + Math.random() * 0.35),
                spd: 5 + Math.random() * 3,
                trail: []
            });
        }

        function explode(x, y) {
            var n = 45 + Math.floor(Math.random() * 35);
            var col = colors[Math.floor(Math.random() * colors.length)];
            for (var i = 0; i < n; i++) {
                var ang = (Math.PI * 2 * i) / n + (Math.random() - 0.5) * 0.3;
                var spd = 1.5 + Math.random() * 4;
                var life = 55 + Math.random() * 45;
                particles.push({
                    x: x, y: y,
                    vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd,
                    life: life, ml: life, color: col,
                    r: 1.5 + Math.random() * 1.5,
                    grav: 0.02 + Math.random() * 0.02,
                    sparkle: Math.random() > 0.5
                });
            }
            for (var j = 0; j < 18; j++) {
                var a2 = Math.random() * Math.PI * 2;
                var s2 = 0.4 + Math.random() * 1.5;
                particles.push({
                    x: x, y: y,
                    vx: Math.cos(a2) * s2, vy: Math.sin(a2) * s2,
                    life: 35, ml: 50, color: '#ffe8f2',
                    r: 1, grav: 0.01, sparkle: true
                });
            }
        }

        function animate(now) {
            var dt = Math.min(now - lastT, 33) / 16;
            lastT = now;
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            for (var i = rockets.length - 1; i >= 0; i--) {
                var r = rockets[i];
                r.y -= r.spd * dt;
                r.trail.push({ x: r.x, y: r.y, a: 1 });
                if (r.trail.length > 10) r.trail.shift();
                for (var j = 0; j < r.trail.length; j++) {
                    r.trail[j].a *= 0.82;
                    ctx.fillStyle = 'rgba(255,220,180,' + (r.trail[j].a * 0.5) + ')';
                    ctx.beginPath();
                    ctx.arc(r.trail[j].x, r.trail[j].y, 2, 0, Math.PI * 2);
                    ctx.fill();
                }
                if (r.y <= r.ty) { explode(r.x, r.y); rockets.splice(i, 1); }
            }

            for (var k = particles.length - 1; k >= 0; k--) {
                var p = particles[k];
                p.x += p.vx * dt;
                p.y += p.vy * dt;
                p.vy += p.grav * dt;
                p.vx *= 0.994;
                p.life -= dt;
                if (p.life <= 0) { particles.splice(k, 1); continue; }
                var ratio = p.life / p.ml;
                var alpha = ratio;
                if (p.sparkle) alpha *= 0.5 + Math.sin(now * 0.02 + k) * 0.5;
                ctx.save();
                ctx.globalAlpha = alpha;
                ctx.fillStyle = p.color;
                ctx.shadowColor = p.color;
                ctx.shadowBlur = 8;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.r * ratio, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }

            if (fwCount < maxFw || particles.length > 0 || rockets.length > 0) {
                requestAnimationFrame(animate);
            } else {
                setTimeout(function () { canvas.classList.remove('active'); }, 600);
            }
        }

        for (var i = 0; i < maxFw; i++) {
            (function (idx) { setTimeout(launch, idx * 450); })(i);
        }
        requestAnimationFrame(animate);
    }

    /* ==================== MESSAGE ==================== */
    function showMessage() {
        var section = document.getElementById('messageSection');
        var line = document.getElementById('quoteLine');
        var scene = document.getElementById('flowerScene');

        scene.style.transform = 'translateY(-50px)';
        setTimeout(function () { section.classList.add('visible'); }, 500);
        setTimeout(function () { line.classList.add('expanded'); }, 1500);
    }

    /* ==================== INIT ==================== */
    function init() {
        try {
            initStars();
            initFlower();
            setTimeout(startTimeline, 600);
        } catch (err) {
            console.error('Init error:', err);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
